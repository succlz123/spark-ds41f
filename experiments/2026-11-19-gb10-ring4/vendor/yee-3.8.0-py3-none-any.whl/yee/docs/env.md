# 环境变量表

这一页列出 Yee 读取的全部环境变量，名称、默认值和作用都以源码为准（`yee/core.py`、`yee/integrations/*.py`、`yee/__main__.py`）。

## 新名字 YEE_*

2.2.0 起，任何 `YEE_XXX` 都等价于 `RECALL_ACCEL_XXX`，`YEE` 等价于 `RECALL_ACCEL`。`import yee` 时会把 `YEE_*` 复制成对应的 `RECALL_ACCEL_*`，但只在后者没设时才复制，所以两者都设时以 `RECALL_ACCEL_*` 为准。

例：`YEE=1 YEE_GIB=0.5` 等同于 `RECALL_ACCEL=1 RECALL_ACCEL_GIB=0.5`。

## 回退顺序

主表里的每个变量，按下面的顺序找第一个非空值（空字符串算没设）：

`RECALL_ACCEL_X` → `SGLANG_D_RECALL_X` → `VLLM_D_RECALL_X` → 更老的名字（`DSV41_RECALL_X` 或 `RECALL_X`，见最后一列）

## 主表

| 变量 | 默认值 | 作用 | 更老的名字 |
|---|---|---|---|
| `RECALL_ACCEL` | `0` | `1` / `true` / `yes` / `on` 打开召回钩子 | `DSV41_RECALL` |
| `RECALL_ACCEL_DIR` | `~/.cache/recall_accel/<分词器摘要前 16 位>` | 记录目录 | `DSV41_RECALL_DIR` |
| `RECALL_ACCEL_GIB` | `0.0625` | 记录容量（GiB） | `DSV41_RECALL_GIB` |
| `RECALL_ACCEL_BACKEND` | `disk` | `disk` / `memory` / `cuda`（`gpu` 同 `cuda`）；cuda 不可用时退回 memory | `RECALL_BACKEND` |
| `RECALL_ACCEL_DEVICE` | 空（cuda 后端用 `cuda:0`） | cuda 后端的设备 | `RECALL_DEVICE` |
| `RECALL_ACCEL_MIN_MATCH` | `16` | 最短匹配长度（token） | `DSV41_RECALL_MIN_MATCH` |
| `RECALL_ACCEL_PRIOR` | `0.8` | 新匹配的预期接受长度先验，按 gamma 的比例计（短窗口匹配减半） | `DSV41_RECALL_PRIOR` |
| `RECALL_ACCEL_READ_ONLY` | `0` | `1` 时只读已有记录、不写入 | `DSV41_RECALL_READ_ONLY` |
| `RECALL_ACCEL_SHARED` | `1` | 多个进程共用一个磁盘记录目录：每个进程都写，每 2 秒读进别的进程写的记录（3.6.0）；`0` 回到 3.5.x 的单 writer。vLLM 是 `VLLM_D_RECALL_SHARED` | `DSV41_RECALL_SHARED` |
| `RECALL_ACCEL_QHASH` | `1` | 提问哈希索引（3.7.0）：把回答按提示的哈希（整段提示、末尾 512 / 128 / 32 个 token）存起来，新请求命中就从第 1 个输出 token 起拿那份旧回答当草稿；`0` 关闭，关闭后行为与 3.6.0 完全相同。vLLM 是 `VLLM_D_RECALL_QHASH` | `DSV41_RECALL_QHASH` |
| `RECALL_ACCEL_MIN_FREE_GIB` | `4` | 磁盘剩余空间低于此值（GiB）时不再写入 | `DSV41_RECALL_MIN_FREE_GIB` |
| `RECALL_ACCEL_TOKENIZER_DIR` | 空（`yee status` 等命令找记录目录时用 `/models/DeepSeek-V4.1-Flash`） | 分词器目录，用来算记录的身份 | `DSV41_RECALL_TOKENIZER_DIR` |
| `RECALL_ACCEL_MODEL_NAME` | 空 | 模型名，写进记录身份 | `DSV41_RECALL_MODEL_NAME` |
| `RECALL_ACCEL_MIA_SITECUSTOMIZE` | `/opt/dsv41/adapter/sitecustomize.py` | sitecustomize 模板先执行的 Mia 原 sitecustomize 路径 | `DSV41_RECALL_MIA_SITECUSTOMIZE` |
| `RECALL_ACCEL_EVICT` | `heat` | 淘汰方式：`heat` / `fifo` | `RECALL_EVICT` |
| `RECALL_ACCEL_HOT_FRAC` | `0.5` | heat 模式下热区占容量的比例（0～0.95；0 等于 fifo） | `RECALL_HOT_FRAC` |
| `RECALL_ACCEL_DEDUP_RUN` | heat 模式 `80`，fifo 模式 `128` | 跳过重复片段的最短长度（下限 32） | `RECALL_DEDUP_RUN` |
| `RECALL_ACCEL_HEAT_HALFLIFE_IDS` | 冷区容量的 1/4（按 id 数） | 热度衰减半衰期 | `RECALL_HEAT_HALFLIFE_IDS` |
| `RECALL_ACCEL_HEAT_SEEN_WEIGHT` | `0.25` | 记录片段再次出现在请求里时累加的热度权重（0 = 不计） | `RECALL_HEAT_SEEN_WEIGHT` |
| `RECALL_ACCEL_PROMOTE_TOKENS` | `32` | 片段升入热区的热度阈值 | `RECALL_PROMOTE_TOKENS` |
| `RECALL_ACCEL_INDEX_DENSITY` | `0.25` | 每个存储 id 分到的哈希槽数（1/64～4） | `RECALL_INDEX_DENSITY` |

主表的 `SGLANG_D_RECALL_*` 和 `VLLM_D_RECALL_*` 名字就是把 `RECALL_ACCEL` 换成对应前缀，例如 `SGLANG_D_RECALL_DIR`、`VLLM_D_RECALL_GIB`。

## 不走回退链的变量

| 变量 | 默认值 | 作用 |
|---|---|---|
| `RECALL_ACCEL_ADAPTER` | `auto` | 只装指定适配器：`auto` / `dspark` / `dflash` / `eagle` / `ngram` / `vllm_spec` / `off` |
| `RECALL_ACCEL_NONGREEDY` | `1` | 采样批次是否接受召回草稿，见 [nongreedy.md](nongreedy.md) |
| `RECALL_ACCEL_WINDOWS` | `16,8,4` | 查找窗口长度（先长后短回退） |

这三个也可以写成 `YEE_ADAPTER`、`YEE_NONGREEDY`、`YEE_WINDOWS`。

## 基座侧变量（不是 Yee 读的）

| 变量 | 由谁读 | 作用 |
|---|---|---|
| `TF_RECALL_AFTER_PRICED` | 打了 Yee 补丁 0001 的 TensorFold | `1` 时 priced 提议器给不出草稿就改问 Recall；不设则与上游一致 |
| `TF_DSV41_LOOKUP_PLAN` | TensorFold | `1` 时 DeepSeek V4.1 用 lookup 计划（priced 提议器之一） |
| `VLLM_USE_V2_MODEL_RUNNER` | vLLM | 设为 `1` 才走 V2 runner，Yee 的 vLLM 钩子在 V2 里 |
| `DSV41_VCAP_CTL` | 打了 `mia-dsv41-vcap` 的 SGLang Mia 镜像 | 逐请求 conf 的控制文件路径，缺省 `/state/vcap_ctl.json`；文件不存在时与 `DSV41_VERIFY_CAP=conf:0.1` 逐位一致 |
| `XY_DSV41_IMAGE_BUDGET_RESERVE` | 打了 `mia-dsv41-image-budget` 的 SGLang Mia 镜像 | `1` 时 D 的图片 token 预算减 1，与 vLLM 的 P 一致；缺省 `0` 与原版一致 |

## KAD（逐请求自适应草稿数）

KAD 的变量由 `yee.kad` 核心和各基座适配器直接读，**不走上面那条 `RECALL_ACCEL_*` 回退链**，也不被 `RECALL_ACCEL_ADAPTER` 收窄。全部默认关；开关打开后策略文件的格式在所有基座通用，见 [kad.md](kad.md)。

### 通用（Python 基座与原生基座都认）

| 变量 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `YEE_KAD` | `0` | KAD 总开关，取 `1` / `true` / `yes` / `on` 打开 | 全部（SGLang、TensorRT-LLM、mlx-lm、transformers、TensorFold、mlx-serve、llama.cpp） |
| `YEE_KAD_DIR` | `~/.cache/yee/kad` | KAD 的默认目录，策略文件和统计文件的默认位置都在它下面 | 全部 |
| `YEE_KAD_POLICY` | `<YEE_KAD_DIR>/kad_policy.json` | 策略文件路径（JSON，格式各基座通用，热加载） | 全部 |
| `YEE_KAD_STATS_FILE` | `<YEE_KAD_DIR>/kad_stats_<基座名>.json` | 统计文件路径，原子写 | 全部 |
| `YEE_KAD_LOG_S` | `30` | 日志与写统计的间隔（秒） | 全部 |
| `YEE_KAD_RELOAD_S` | `1.0` | 策略文件 stat 的最小间隔（秒） | 全部 |
| `YEE_KAD_RELOAD_EVERY` | `64` | 多 rank 时每多少步同步一次策略（`step % 值 == 0` 时由 rank0 读文件再广播） | SGLang、TensorRT-LLM |

### vLLM（沿用自己的前缀）

| 变量 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `VLLM_D_RECALL_KAD` | `0` | KAD 开关；还要 `VLLM_D_RECALL=1`（总开关） | vLLM |
| `VLLM_D_RECALL_KAD_POLICY` | `<VLLM_D_RECALL_DIR>/kad_policy.json` | 策略文件 | vLLM |
| `VLLM_D_RECALL_KAD_STATS_FILE` | `<VLLM_D_RECALL_DIR>/kad_stats.json` | 调度器侧统计 | vLLM |
| `VLLM_D_RECALL_KAD_LOG_S` | `30` | 日志与统计间隔（秒） | vLLM |
| `VLLM_D_RECALL_KAD_RELOAD_S` | `1.0` | 策略文件 stat 最小间隔（秒） | vLLM |
| `VLLM_D_RECALL_NONGREEDY` | `0` | 3.5.0：`1` 时温度大于 0 的行也接受召回草稿，被覆写的位置把草稿分布改成单点分布 | vLLM |
| `VLLM_D_RECALL_SHADOW` | `0` | 3.5.0：`1` 时写影子统计（只记录、不改行为） | vLLM |
| `VLLM_D_RECALL_SHADOW_DIR` | 临时目录下的 `vllm_d_recall_shadow` | 影子统计 JSONL 的目录 | vLLM |
| `VLLM_D_RECALL_SHADOW_TOPK_RATE` | `0.01` | 影子统计里 topk 记录的抽样率 | vLLM |

### TensorFold

| 变量 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `TF_KAD` | `0` | KAD 开关，取 `1` / `true` / `yes` / `on`；也可只设 `YEE_KAD=1` | TensorFold |
| `TF_KAD_POLICY` | `<YEE_KAD_DIR>/kad_policy.json` | 策略文件；未设时用 `YEE_KAD_POLICY` | TensorFold |
| `TF_KAD_STATS_FILE` | `<YEE_KAD_DIR>/kad_stats_tensorfold.json` | 统计文件；未设时用 `YEE_KAD_STATS_FILE` | TensorFold |
| `TF_KAD_LOG_S` | `30` | 日志与写统计的间隔（秒）；未设时用 `YEE_KAD_LOG_S` | TensorFold |
| `TF_KAD_RELOAD_S` | `1.0` | 策略热加载的最小间隔（秒）；未设时用 `YEE_KAD_RELOAD_S` | TensorFold |

### mlx-serve

| 变量 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `MLX_SERVE_KAD` | `0` | KAD 开关，取 `1` / `true` / `yes` / `on`；也可只设 `YEE_KAD=1` | mlx-serve |
| `MLX_SERVE_KAD_POLICY` | `<YEE_KAD_DIR>/kad_policy.json` | 策略文件；未设时用 `YEE_KAD_POLICY` | mlx-serve |
| `MLX_SERVE_KAD_STATS_FILE` | `<YEE_KAD_DIR>/kad_stats_mlx-serve.json` | 统计文件；未设时用 `YEE_KAD_STATS_FILE` | mlx-serve |
| `MLX_SERVE_KAD_LOG_S` | `30` | 日志与写统计的间隔（秒）；未设时用 `YEE_KAD_LOG_S` | mlx-serve |
| `MLX_SERVE_KAD_RELOAD_S` | `1.0` | 策略热加载的最小间隔（秒）；未设时用 `YEE_KAD_RELOAD_S` | mlx-serve |

### llama.cpp（命令行参数优先，参数名带 `LLAMA_ARG_` 前缀）

| 变量 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `LLAMA_ARG_KAD` | `0` | KAD 开关，等价于命令行 `--kad`；也可只设 `YEE_KAD=1` | llama.cpp |
| `LLAMA_ARG_KAD_POLICY` | `<YEE_KAD_DIR>/kad_policy.json` | 策略文件，等价于命令行 `--kad-policy FNAME`；未设时用 `YEE_KAD_POLICY` | llama.cpp |

llama.cpp 的策略与统计路径也可用 `YEE_KAD_POLICY` / `YEE_KAD_STATS_FILE`（默认 `<YEE_KAD_DIR>/kad_stats_llama.cpp.json`）、`YEE_KAD_LOG_S`、`YEE_KAD_RELOAD_S`。

### strata（命令行参数优先）

| 变量 / 参数 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `RECALL_ACCEL` / `YEE_RECALL`，参数 `--recall` | `0` | 召回开关；`--no-recall` 压过环境变量 | strata |
| `RECALL_ACCEL_DIR`，参数 `--recall-dir` | 空（内存记录） | 记录目录，多个进程可共用 | strata |
| `RECALL_ACCEL_GIB`，参数 `--recall-gib` | `0.0625` | 记录容量（GiB） | strata |
| `RECALL_ACCEL_READ_ONLY`，参数 `--recall-read-only` | `0` | 只用旧记录，不写新记录 | strata |
| `STRATA_RECALL_SHARED` | `1` | 多副本共用 `--recall-dir`：每组副本都写，每 2 秒读进其它组写的记录（3.6.0）；`0` 回到 3.5.x 的单 writer | strata |
| `RECALL_ACCEL_MIN_MATCH` | `16` | 最短匹配（token） | strata |
| `YEE_RECALL_STATS_FILE` | `~/.cache/yee/recall/recall_stats_strata.json` | 统计文件 | strata |
| `YEE_RECALL_LOG_S` | `30` | 周期日志间隔（秒） | strata |

### llama.cpp MTP 草稿头（3.5.2，需补丁 llama.cpp-mtp-vocab）

| 变量 | 默认值 | 作用 | 适用基座 |
|---|---|---|---|
| `YEE_MTP_VOCAB_N` | 空（不截断） | MTP 草稿头只算 token id 0～N-1 的 logits；0 或不小于词表大小时不截断 | llama.cpp（qwen35 / qwen35moe） |

### LMDeploy 与 cuteafd

两者都是 native：KAD 不介入，只按 12 的草稿数原生跑，没有自己的 KAD 环境变量。LMDeploy 仍读 `YEE_KAD`（autoload 装上后只打印一行 native 原因），cuteafd 没有 KAD 开关。

## selftest 的处理

`yee selftest` 在子进程里跑测试前会清掉 `YEE`、`YEE_*`、`RECALL_ACCEL*`、`SGLANG_D_RECALL*`、`VLLM_D_RECALL*`、`DSV41_RECALL*`，避免线上配置影响测试结果。
